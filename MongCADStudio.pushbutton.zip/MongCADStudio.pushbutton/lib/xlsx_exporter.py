# -*- coding: utf-8 -*-
"""
Pure-Python .xlsx OOXML Reader / Writer & Foundation Project Exporter (TCVN 5574:2018).
Upgraded from xlsxio.py — no external openpyxl/pandas dependencies required in pyRevit CPython 3.
"""

import os
import re
import zipfile
import xml.etree.ElementTree as ET
from xml.sax.saxutils import escape

from calc_engine import (
    compute_footing,
    compute_foundation_beam,
    compute_pile_cap,
    compute_strip_footing,
    format_elevation,
)

_M = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
_R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
_PR = "http://schemas.openxmlformats.org/package/2006/relationships"

_ILLEGAL = re.compile(u"[\x00-\x08\x0b\x0c\x0e-\x1f]")


def _col_name(i):
    s = ""
    i += 1
    while i:
        i, r = divmod(i - 1, 26)
        s = chr(65 + r) + s
    return s


def _col_index(ref):
    m = re.match(r"[A-Za-z]+", ref)
    letters = m.group(0).upper() if m else "A"
    n = 0
    for ch in letters:
        n = n * 26 + (ord(ch) - 64)
    return n - 1


def _cell_xml(ref, v, style):
    st = ' s="%d"' % style if style else ""
    if v is None or v == "":
        return '<c r="%s"%s/>' % (ref, st) if style else ""
    if isinstance(v, bool):
        return '<c r="%s"%s t="b"><v>%d</v></c>' % (ref, st, 1 if v else 0)
    if isinstance(v, int):
        return '<c r="%s"%s><v>%d</v></c>' % (ref, st, v)
    if isinstance(v, float):
        if v != v or v in (float("inf"), float("-inf")):
            return ""
        return '<c r="%s"%s><v>%s</v></c>' % (ref, st, format(v, ".10g"))
    text = escape(_ILLEGAL.sub("", u"%s" % v))
    return (
        '<c r="%s"%s t="inlineStr"><is><t xml:space="preserve">%s</t></is></c>'
        % (ref, st, text)
    )


def _sheet_xml(rows, header=True):
    ncols = max([len(r) for r in rows] + [1])
    widths = [10] * ncols
    for r in rows[:300]:
        for j, v in enumerate(r):
            if v is None:
                continue
            w = len(u"%s" % v) + 3
            if w > widths[j]:
                widths[j] = min(w, 42)
    out = [
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
        '<worksheet xmlns="%s" xmlns:r="%s">' % (_M, _R),
    ]
    if header:
        out.append(
            '<sheetViews><sheetView workbookViewId="0">'
            '<pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/>'
            "</sheetView></sheetViews>"
        )
    out.append("<cols>")
    for j, w in enumerate(widths):
        out.append('<col min="%d" max="%d" width="%d" customWidth="1"/>' % (j + 1, j + 1, w))
    out.append("</cols><sheetData>")
    for i, r in enumerate(rows):
        cells = []
        style = 1 if (header and i == 0) else 0
        for j, v in enumerate(r):
            c = _cell_xml("%s%d" % (_col_name(j), i + 1), v, style)
            if c:
                cells.append(c)
        out.append('<row r="%d">%s</row>' % (i + 1, "".join(cells)))
    out.append("</sheetData></worksheet>")
    return "".join(out)


_STYLES = (
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    '<styleSheet xmlns="%s">'
    '<fonts count="2"><font><sz val="11"/><name val="Calibri"/></font>'
    '<font><b/><sz val="11"/><name val="Calibri"/></font></fonts>'
    '<fills count="3"><fill><patternFill patternType="none"/></fill>'
    '<fill><patternFill patternType="gray125"/></fill>'
    '<fill><patternFill patternType="solid"><fgColor rgb="FFD9E1F2"/></patternFill></fill></fills>'
    '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
    '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
    '<cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
    '<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/></cellXfs>'
    "</styleSheet>" % _M
)


def _sanitize_sheet_name(name, used):
    clean = re.sub(r'[:\\/?*\[\]]', "_", u"%s" % name).strip() or "Sheet"
    clean = clean[:31]
    base = clean
    idx = 2
    while clean.lower() in used:
        sfx = "_%d" % idx
        clean = base[: 31 - len(sfx)] + sfx
        idx += 1
    used.add(clean.lower())
    return clean


def write_xlsx(path, sheets):
    """sheets: list[(ten_sheet, rows)], rows = list[list]. Dong dau la tieu de."""
    parent = os.path.dirname(os.path.abspath(path))
    if parent and not os.path.exists(parent):
        os.makedirs(parent)
    tmp = path + ".tmp"
    n = len(sheets)
    used_names = set()
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        ct = [
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
            '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">',
            '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>',
            '<Default Extension="xml" ContentType="application/xml"/>',
            '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>',
            '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>',
        ]
        for i in range(n):
            ct.append(
                '<Override PartName="/xl/worksheets/sheet%d.xml" '
                'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
                % (i + 1)
            )
        ct.append("</Types>")
        z.writestr("[Content_Types].xml", "".join(ct))
        z.writestr(
            "_rels/.rels",
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="%s"><Relationship Id="rId1" '
            'Type="%s/officeDocument" Target="xl/workbook.xml"/></Relationships>' % (_PR, _R),
        )
        wb = [
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
            '<workbook xmlns="%s" xmlns:r="%s"><sheets>' % (_M, _R),
        ]
        rel = [
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
            '<Relationships xmlns="%s">' % _PR,
        ]
        for i, (raw_name, rows) in enumerate(sheets):
            name = _sanitize_sheet_name(raw_name, used_names)
            wb.append('<sheet name="%s" sheetId="%d" r:id="rId%d"/>' % (escape(name), i + 1, i + 1))
            rel.append(
                '<Relationship Id="rId%d" Type="%s/worksheet" Target="worksheets/sheet%d.xml"/>'
                % (i + 1, _R, i + 1)
            )
            z.writestr("xl/worksheets/sheet%d.xml" % (i + 1), _sheet_xml(rows))
        wb.append("</sheets></workbook>")
        rel.append(
            '<Relationship Id="rId%d" Type="%s/styles" Target="styles.xml"/></Relationships>' % (n + 1, _R)
        )
        z.writestr("xl/workbook.xml", "".join(wb))
        z.writestr("xl/_rels/workbook.xml.rels", "".join(rel))
        z.writestr("xl/styles.xml", _STYLES)
    os.replace(tmp, path)


def _num(txt):
    try:
        f = float(txt)
    except Exception:
        return txt
    if f == int(f) and abs(f) < 1e15 and "." not in txt and "E" not in txt.upper():
        return int(f)
    return f


def read_xlsx(path):
    """Tra ve list[(ten_sheet, rows)] theo thu tu trong file."""
    z = zipfile.ZipFile(path)
    try:
        names = set(z.namelist())
        shared = []
        if "xl/sharedStrings.xml" in names:
            root = ET.fromstring(z.read("xl/sharedStrings.xml"))
            for si in root.findall("{%s}si" % _M):
                parts = []
                for node in si.iter():
                    if node.tag == "{%s}t" % _M:
                        parts.append(node.text or "")
                shared.append("".join(parts))
        wb = ET.fromstring(z.read("xl/workbook.xml"))
        rels = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
        targets = {}
        for r in rels:
            targets[r.get("Id")] = r.get("Target")
        result = []
        sheets = wb.find("{%s}sheets" % _M)
        for sh in sheets:
            name = sh.get("name")
            rid = sh.get("{%s}id" % _R)
            tgt = targets.get(rid, "").lstrip("/")
            if not tgt.startswith("xl/"):
                tgt = "xl/" + tgt
            if tgt not in names:
                continue
            root = ET.fromstring(z.read(tgt))
            grid = {}
            maxr = 0
            for row in root.iter("{%s}row" % _M):
                for c in row.findall("{%s}c" % _M):
                    ref = c.get("r")
                    if not ref:
                        continue
                    ri = int(re.search(r"\d+", ref).group(0)) - 1
                    ci = _col_index(ref)
                    t = c.get("t")
                    v = c.find("{%s}v" % _M)
                    val = None
                    if t == "inlineStr":
                        is_ = c.find("{%s}is" % _M)
                        if is_ is not None:
                            val = "".join((x.text or "") for x in is_.iter("{%s}t" % _M))
                    elif v is None or v.text is None:
                        val = None
                    elif t == "s":
                        try:
                            val = shared[int(v.text)]
                        except Exception:
                            val = None
                    elif t == "b":
                        val = bool(int(v.text))
                    elif t in ("str", "e"):
                        val = v.text
                    else:
                        val = _num(v.text)
                    if val is not None:
                        grid[(ri, ci)] = val
                        if ri > maxr:
                            maxr = ri
            rows = []
            if grid:
                maxc = max(c for (_, c) in grid)
                for ri in range(maxr + 1):
                    rows.append([grid.get((ri, ci)) for ci in range(maxc + 1)])
            result.append((name, rows))
        return result
    finally:
        z.close()


def _tcvn_status(comp):
    if comp.get("hasError"):
        return u"LỖI"
    if comp.get("hasWarn"):
        return u"LƯU Ý"
    return u"ĐẠT"


def export_project_to_xlsx(filepath, footings, strips, pile_caps, beams, scan_notes=None, doc_title=""):
    """
    Xuat toan bo du an 4 loai mong ra file Excel (.xlsx) gom 6 sheet:
    TongHopMark, MongDon, DaiMong_Coc, MongBang, DamMong, ThongTin_CanhBao.
    """
    tong_hop = [[
        u"STT",
        u"Loại móng",
        u"Tên / Mark",
        u"Số lượng",
        u"Kích thước (mm)",
        u"Cao trình (m)",
        u"KL thép 1 CK (kg)",
        u"Tổng KL thép (kg)",
        u"Kiểm tra TCVN",
        u"Ghi chú",
    ]]

    don_rows = [[
        u"Tên / Mark", u"SL", u"B (mm)", u"L (mm)", u"H (mm)", u"h_mép (mm)",
        u"Z đáy (m)", u"Cột b×h (mm)", u"Vị trí cột",
        u"Thép đáy X", u"Thép đáy Y", u"Cổ cột / Đai",
        u"KL 1 móng (kg)", u"Tổng KL (kg)", u"TCVN", u"Ghi chú",
    ]]

    coc_rows = [[
        u"Tên / Mark", u"SL", u"B (mm)", u"L (mm)", u"H (mm)", u"Z mặt đài (m)",
        u"D cọc (mm)", u"Hình cọc", u"Số cọc", u"Ngàm cọc (mm)",
        u"Lưới đáy B1/B2", u"Lưới trên T1/T2", u"Thép vách",
        u"KL 1 đài (kg)", u"Tổng KL (kg)", u"TCVN", u"Ghi chú",
    ]]

    bang_rows = [[
        u"Tên / Mark", u"SL", u"B tổng (mm)", u"B dầm (mm)", u"Cánh T/P (mm)", u"H dầm (mm)",
        u"Tổng dài L (mm)", u"Số nhịp", u"Z đỉnh (m)",
        u"Thép trên", u"Thép dưới", u"Đai dầm", u"Thép ngang cánh",
        u"KL 1 móng (kg)", u"Tổng KL (kg)", u"TCVN", u"Ghi chú",
    ]]

    dam_rows = [[
        u"Tên / Mark", u"SL", u"B dầm (mm)", u"H dầm (mm)", u"Tổng dài L (mm)",
        u"Số nhịp", u"Số gối", u"Gối trục", u"Z đỉnh (m)",
        u"Thép trên L1", u"Thép trên L2", u"Thép dưới", u"Đai gối / nhịp",
        u"KL 1 dầm (kg)", u"Tổng KL (kg)", u"TCVN", u"Ghi chú",
    ]]

    warn_rows = [[u"Nguồn / Loại", u"Cấu kiện", u"Mức độ", u"Nội dung kiểm tra / Lưu ý Revit & TCVN"]]
    if doc_title:
        warn_rows.append([u"Mô hình", doc_title, u"THÔNG TIN", u"Xuất từ Móng CAD Studio (pyRevit + Revit 2025)"])
    for n in (scan_notes or []):
        warn_rows.append([u"Quét Revit/DXF", u"Tổng quát", u"LƯU Ý", u"%s" % n])

    stt = 0
    grand_kg = 0.0
    grand_qty = 0

    for it in footings:
        stt += 1
        c = compute_footing(it)
        kg1 = c["khoiLuongThepDay1Mong"]
        kgt = c["khoiLuongThepDayTong"]
        sl = int(it.get("soLuong", 1))
        grand_kg += kgt
        grand_qty += sl
        st = _tcvn_status(c)
        sz = "%s×%s×%s" % (it["B"], it["L"], it["H"])
        elv = format_elevation(it["caoTrinhDay"])
        tong_hop.append([stt, u"Móng Đơn", it["ten"], sl, sz, elv, kg1, kgt, st, it.get("ghiChu", "")])
        don_rows.append([
            it["ten"], sl, it["B"], it["L"], it["H"], it["hMep"], elv,
            "%s×%s" % (it["cotB"], it["cotH"]), it.get("viTriCotMode", "center"),
            "Ø%ga%g" % (it["thepPhuongX"]["d"], it["thepPhuongX"]["a"]),
            "Ø%ga%g" % (it["thepPhuongY"]["d"], it["thepPhuongY"]["a"]),
            "Ø%g / Ø%ga%g" % (it["thepCotD"], it["thepDaiD"], it["thepDaiA"]),
            kg1, kgt, st, it.get("ghiChu", ""),
        ])
        for chk in c["checks"]:
            if chk["status"] != "ok":
                warn_rows.append([u"Móng Đơn", it["ten"], chk["status"].upper(), chk["detail"]])

    for it in pile_caps:
        stt += 1
        c = compute_pile_cap(it)
        kg1 = c["khoiLuong1Dai"]
        kgt = c["khoiLuongTong"]
        sl = int(it.get("soLuong", 1))
        grand_kg += kgt
        grand_qty += sl
        st = _tcvn_status(c)
        sz = "%s×%s×%s (%d cọc)" % (it["B"], it["L"], it["H"], c["tongSoCoc"])
        elv = format_elevation(it["caoTrinhMatDai"])
        tong_hop.append([stt, u"Móng Cọc", it["ten"], sl, sz, elv, kg1, kgt, st, it.get("ghiChu", "")])
        coc_rows.append([
            it["ten"], sl, it["B"], it["L"], it["H"], elv,
            it["cocD"], u"Vuông" if it.get("cocHinh") == "square" else u"Tròn", c["tongSoCoc"], it["ngamCoc"],
            "Ø%ga%g / Ø%ga%g" % (it["thepDuoiX"]["d"], it["thepDuoiX"]["a"], it["thepDuoiY"]["d"], it["thepDuoiY"]["a"]),
            "Ø%ga%g / Ø%ga%g" % (it["thepTrenX"]["d"], it["thepTrenX"]["a"], it["thepTrenY"]["d"], it["thepTrenY"]["a"]),
            "%d lớp Ø%ga%g" % (it["soTangThepVach"], it["thepVach"]["d"], it["thepVach"]["a"]),
            kg1, kgt, st, it.get("ghiChu", ""),
        ])
        for chk in c["checks"]:
            if chk["status"] != "ok":
                warn_rows.append([u"Móng Cọc", it["ten"], chk["status"].upper(), chk["detail"]])

    for it in strips:
        stt += 1
        c = compute_strip_footing(it)
        kg1 = c["khoiLuong1Mong"]
        kgt = c["khoiLuongTong"]
        sl = int(it.get("soLuong", 1))
        grand_kg += kgt
        grand_qty += sl
        st = _tcvn_status(c)
        sz = "B=%s (dầm %s) × H=%s · L=%s" % (c["B_mong"], it["B_dam"], it["H_dam"], c["tongL"])
        elv = format_elevation(it["caoTrinhTop"])
        tong_hop.append([stt, u"Móng Băng", it["ten"], sl, sz, elv, kg1, kgt, st, it.get("ghiChu", "")])
        bang_rows.append([
            it["ten"], sl, c["B_mong"], it["B_dam"], "%s / %s" % (it["canhTrai"], it["canhPhai"]),
            it["H_dam"], c["tongL"], len(it.get("spans", [])), elv,
            "%gØ%g" % (it["thepTrenCount"], it["thepTrenD"]),
            "%gØ%g" % (it["thepDuoiCount"], it["thepDuoiD"]),
            "Ø%ga%g" % (it["thepDaiD"], it["thepDaiA"]),
            "Ø%ga%g" % (it["thepNgangCanhD"], it["thepNgangCanhA"]),
            kg1, kgt, st, it.get("ghiChu", ""),
        ])
        for chk in c["checks"]:
            if chk["status"] != "ok":
                warn_rows.append([u"Móng Băng", it["ten"], chk["status"].upper(), chk["detail"]])

    for it in beams:
        stt += 1
        c = compute_foundation_beam(it)
        kg1 = c["khoiLuong1Dam"]
        kgt = c["khoiLuongTong"]
        sl = int(it.get("soLuong", 1))
        grand_kg += kgt
        grand_qty += sl
        st = _tcvn_status(c)
        sz = "%s×%s · L=%s" % (it["B_dam"], it["H_dam"], c["tongL"])
        elv = format_elevation(it["caoTrinhTop"])
        sup_str = " - ".join(s["trucLabel"] for s in it.get("supports", []))
        tong_hop.append([stt, u"Dầm Móng", it["ten"], sl, sz, elv, kg1, kgt, st, it.get("ghiChu", "")])
        dam_rows.append([
            it["ten"], sl, it["B_dam"], it["H_dam"], c["tongL"], len(it.get("spans", [])),
            len(it.get("supports", [])), sup_str, elv,
            "%gØ%g" % (it["thepTren1Count"], it["thepTren1D"]),
            "%gØ%g" % (it["thepTren2Count"], it["thepTren2D"]),
            "%gØ%g" % (it["thepDuoiCount"], it["thepDuoiD"]),
            "Ø%ga%g/%g" % (it["thepDaiD"], it["thepDaiAGoi"], it["thepDaiANhip"]),
            kg1, kgt, st, it.get("ghiChu", ""),
        ])
        for chk in c["checks"]:
            if chk["status"] != "ok":
                warn_rows.append([u"Dầm Móng", it["ten"], chk["status"].upper(), chk["detail"]])

    tong_hop.append([
        "", u"TỔNG CỘNG", "%d loại" % stt, grand_qty, "", "", "", round(grand_kg, 1), "", u"Đơn vị: mm / m / kg",
    ])

    sheets = [
        ("TongHopMark", tong_hop),
        ("MongDon", don_rows),
        ("DaiMong_Coc", coc_rows),
        ("MongBang", bang_rows),
        ("DamMong", dam_rows),
        ("ThongTin_CanhBao", warn_rows),
    ]
    write_xlsx(filepath, sheets)
    return {"path": filepath, "typesCount": stt, "totalQty": grand_qty, "totalKg": round(grand_kg, 1)}
